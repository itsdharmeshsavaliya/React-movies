import React from "react";
// import { useGloalContext } from "./Context";

const Search = () => {

    // const { query, setQuery } = useGloalContext();



    return (
        <>
            {/* <div className="container">
                <form onSubmit={(e) => e.preventDefault()}>
                    <div className="input-group mb-3">
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search Your Movie"
                            aria-label="Recipient's username"
                            aria-describedby="button-addon2"
                            value={query}
                            onChange={(event) => setQuery(event.target.value)}
                        />
                        <button
                            className="btn btn-outline-secondary"
                            type="submit"
                            id="button-addon2"
                        >
                            Search
                        </button>
                    </div>
                </form>
            </div> */}

        </>
    );
};

export default Search;
