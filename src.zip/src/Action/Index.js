

// export const Addboard = (data) => {
//     return {
//         type: 'ADD_BOARD',
//         payload: {
//             id: new Date(),
//             Data: data
//         }
//     }
// }

// export const DeleteUserOnBoard = (id) => {
//     return {
//         type: 'DELET_USER_ON_BOARD',
//         id
//     }
// }


// export const EditUserOnBoard = (userId, newData) => {
//     return {
//         type: 'EDIT_USER_ON_BOARD',
//         userId,
//         newData
//     }
// }
