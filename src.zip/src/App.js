import './App.css';

import NavBar from './Components/NavBar';

function App() {
  return (
    <>
      <NavBar />

    </>
  );
}

export default App;
