import React from "react";

const MyBoard = () => {
    return (
        <>
            <h3 className="text-center mt-3">My Board</h3>
        </>
    );
};

export default MyBoard;
