import AddCard from "./AddCard";
import { combineReducers } from "redux";

const rootReducers = combineReducers({
    AddCard,
})


export default rootReducers;